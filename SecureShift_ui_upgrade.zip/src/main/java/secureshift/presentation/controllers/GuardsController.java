package secureshift.presentation.controllers;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import secureshift.data.GuardRepositoryJDBC;
import secureshift.domain.Guard;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class GuardsController {

    @FXML private TableView<Guard> guardsTable;
    @FXML private TableColumn<Guard, String> colId;
    @FXML private TableColumn<Guard, String> colName;
    @FXML private TableColumn<Guard, String> colLatitude;
    @FXML private TableColumn<Guard, String> colLongitude;
    @FXML private TableColumn<Guard, String> colAvailable;
    @FXML private TableColumn<Guard, String> colSkills;
    @FXML private Label statusLabel;

    private final GuardRepositoryJDBC repo = new GuardRepositoryJDBC();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getId()));
        colName.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));
        colLatitude.setCellValueFactory(c -> new SimpleStringProperty(String.format("%.4f", c.getValue().getLatitude())));
        colLongitude.setCellValueFactory(c -> new SimpleStringProperty(String.format("%.4f", c.getValue().getLongitude())));
        colAvailable.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().isAvailable() ? "✅ Yes" : "❌ No"));
        colSkills.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getSkills() != null ? String.join(", ", c.getValue().getSkills()) : ""));

        // Row colour: green = available, red = unavailable
        guardsTable.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(Guard g, boolean empty) {
                super.updateItem(g, empty);
                if (g == null || empty) {
                    setStyle("");
                } else if (g.isAvailable()) {
                    setStyle("-fx-background-color: #e8f5e9;");
                } else {
                    setStyle("-fx-background-color: #ffebee;");
                }
            }
        });

        refresh();
    }

    @FXML
    public void refresh() {
        try {
            List<Guard> guards = repo.loadAllGuards();
            guardsTable.setItems(FXCollections.observableArrayList(guards));
            setStatus("✅ Loaded " + guards.size() + " guards", false);
        } catch (Exception e) {
            setStatus("❌ Error loading guards: " + e.getMessage(), true);
        }
    }

    @FXML
    private void addGuard() {
        showGuardDialog(null);
    }

    @FXML
    private void editGuard() {
        Guard selected = guardsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No Selection", "Please select a guard to edit.");
            return;
        }
        showGuardDialog(selected);
    }

    @FXML
    private void deleteGuard() {
        Guard selected = guardsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No Selection", "Please select a guard to delete.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Guard");
        confirm.setHeaderText("Delete " + selected.getName() + "?");
        confirm.setContentText("This action cannot be undone.");
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                try {
                    repo.deleteGuard(selected.getId());
                    setStatus("✅ Guard deleted: " + selected.getName(), false);
                    refresh();
                } catch (Exception e) {
                    setStatus("❌ Error deleting guard: " + e.getMessage(), true);
                }
            }
        });
    }

    @FXML
    private void toggleAvailability() {
        Guard selected = guardsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No Selection", "Please select a guard.");
            return;
        }
        selected.setAvailable(!selected.isAvailable());
        try {
            repo.updateGuard(selected);
            setStatus("✅ " + selected.getName() + " availability updated", false);
            refresh();
        } catch (Exception e) {
            setStatus("❌ Error updating guard: " + e.getMessage(), true);
        }
    }

    private void showGuardDialog(Guard existing) {
        Dialog<Guard> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add New Guard" : "Edit Guard");
        dialog.setHeaderText(existing == null ? "Enter guard details:" : "Edit guard details:");

        ButtonType saveBtn = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        // Form fields
        TextField nameField  = new TextField(existing != null ? existing.getName() : "");
        TextField latField   = new TextField(existing != null ? String.valueOf(existing.getLatitude()) : "51.5074");
        TextField lonField   = new TextField(existing != null ? String.valueOf(existing.getLongitude()) : "-0.1278");
        TextField skillsField = new TextField(existing != null && existing.getSkills() != null
                ? String.join(", ", existing.getSkills()) : "");
        CheckBox availBox = new CheckBox("Available");
        availBox.setSelected(existing == null || existing.isAvailable());

        nameField.setPromptText("e.g. John Smith");
        latField.setPromptText("e.g. 51.5074");
        lonField.setPromptText("e.g. -0.1278");
        skillsField.setPromptText("e.g. PATROL, CCTV, FIRST_AID");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));
        grid.addRow(0, new Label("Name: *"), nameField);
        grid.addRow(1, new Label("Latitude:"), latField);
        grid.addRow(2, new Label("Longitude:"), lonField);
        grid.addRow(3, new Label("Skills:"), skillsField);
        grid.addRow(4, new Label(""), availBox);
        GridPane.setHgrow(nameField, Priority.ALWAYS);
        nameField.setPrefWidth(280);

        dialog.getDialogPane().setContent(grid);
        nameField.requestFocus();

        dialog.setResultConverter(btn -> {
            if (btn == saveBtn) {
                if (nameField.getText().isBlank()) return null;
                String id = existing != null ? existing.getId() : "G" + System.currentTimeMillis();
                double lat = parseDouble(latField.getText(), 0.0);
                double lon = parseDouble(lonField.getText(), 0.0);
                List<String> skills = skillsField.getText().isBlank()
                        ? List.of()
                        : Arrays.stream(skillsField.getText().split(","))
                                .map(String::trim).filter(s -> !s.isEmpty()).toList();
                return new Guard(id, nameField.getText().trim(), lat, lon, availBox.isSelected(), skills);
            }
            return null;
        });

        dialog.showAndWait().ifPresent(guard -> {
            try {
                if (existing == null) {
                    repo.saveGuard(guard);
                    setStatus("✅ Guard added: " + guard.getName(), false);
                } else {
                    repo.updateGuard(guard);
                    setStatus("✅ Guard updated: " + guard.getName(), false);
                }
                refresh();
            } catch (Exception e) {
                setStatus("❌ Error saving guard: " + e.getMessage(), true);
            }
        });
    }

    private double parseDouble(String s, double fallback) {
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return fallback; }
    }

    private void setStatus(String msg, boolean error) {
        if (statusLabel != null) {
            statusLabel.setText(msg);
            statusLabel.setTextFill(error ? Color.RED : Color.GREEN);
        }
        System.out.println(msg);
    }

    private void showAlert(String title, String msg) {
        new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK).showAndWait();
    }
}
