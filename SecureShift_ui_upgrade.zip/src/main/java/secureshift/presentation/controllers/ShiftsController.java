package secureshift.presentation.controllers;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import secureshift.data.ShiftRepositoryJDBC;
import secureshift.data.SiteRepositoryJDBC;
import secureshift.domain.Shift;
import secureshift.domain.Site;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ShiftsController {

    @FXML private TableView<Shift> shiftsTable;
    @FXML private TableColumn<Shift, String> colId;
    @FXML private TableColumn<Shift, String> colSite;
    @FXML private TableColumn<Shift, String> colStart;
    @FXML private TableColumn<Shift, String> colEnd;
    @FXML private TableColumn<Shift, String> colDuration;
    @FXML private TableColumn<Shift, String> colGuard;
    @FXML private TableColumn<Shift, String> colStatus;
    @FXML private Label statusLabel;

    private final ShiftRepositoryJDBC shiftRepo = new ShiftRepositoryJDBC();
    private final SiteRepositoryJDBC  siteRepo  = new SiteRepositoryJDBC();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");

    @FXML
    public void initialize() {
        colId.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getId()));
        colSite.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getSite() != null ? c.getValue().getSite().getName() : "Unknown"));
        colStart.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getStartTime() != null ? c.getValue().getStartTime().format(FMT) : ""));
        colEnd.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getEndTime() != null ? c.getValue().getEndTime().format(FMT) : ""));
        colDuration.setCellValueFactory(c -> new SimpleStringProperty(
                String.format("%.1f hrs", c.getValue().getDurationHours())));
        colGuard.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getAssignedGuard() != null
                        ? c.getValue().getAssignedGuard().getName() : "Unassigned"));
        colStatus.setCellValueFactory(c -> {
            Shift s = c.getValue();
            LocalDateTime now = LocalDateTime.now();
            String status;
            if (s.getEndTime() != null && s.getEndTime().isBefore(now))       status = "Completed";
            else if (s.getStartTime() != null && s.getStartTime().isBefore(now)) status = "Active";
            else                                                                status = "Upcoming";
            return new SimpleStringProperty(status);
        });

        // Colour rows by status
        shiftsTable.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(Shift s, boolean empty) {
                super.updateItem(s, empty);
                if (s == null || empty) { setStyle(""); return; }
                LocalDateTime now = LocalDateTime.now();
                if (s.getEndTime() != null && s.getEndTime().isBefore(now))
                    setStyle("-fx-background-color: #f5f5f5;");
                else if (s.getStartTime() != null && s.getStartTime().isBefore(now))
                    setStyle("-fx-background-color: #e3f2fd;");
                else
                    setStyle("-fx-background-color: #e8f5e9;");
            }
        });

        refresh();
    }

    @FXML
    public void refresh() {
        try {
            List<Shift> shifts = shiftRepo.loadAllShifts();
            shiftsTable.setItems(FXCollections.observableArrayList(shifts));
            setStatus("✅ Loaded " + shifts.size() + " shifts", false);
        } catch (Exception e) {
            setStatus("❌ Error loading shifts: " + e.getMessage(), true);
        }
    }

    @FXML
    private void createShift() {
        List<Site> sites;
        try {
            sites = siteRepo.loadAllSites();
        } catch (Exception e) {
            setStatus("❌ Could not load sites: " + e.getMessage(), true);
            return;
        }
        if (sites.isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "No sites exist. Please add a site first.", ButtonType.OK).showAndWait();
            return;
        }

        Dialog<Shift> dialog = new Dialog<>();
        dialog.setTitle("Create New Shift");
        dialog.setHeaderText("Enter shift details:");

        ButtonType saveBtn = new ButtonType("Create", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        ComboBox<Site> siteBox = new ComboBox<>(FXCollections.observableArrayList(sites));
        siteBox.setPromptText("Select a site...");
        siteBox.setPrefWidth(280);
        siteBox.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Site s, boolean empty) {
                super.updateItem(s, empty);
                setText(empty || s == null ? "" : s.getName() + " (" + s.getRegion() + ")");
            }
        });
        siteBox.setButtonCell(new ListCell<>() {
            @Override protected void updateItem(Site s, boolean empty) {
                super.updateItem(s, empty);
                setText(empty || s == null ? "" : s.getName());
            }
        });

        DatePicker datePicker = new DatePicker(LocalDate.now().plusDays(1));
        TextField  startTime  = new TextField("08:00");
        TextField  endTime    = new TextField("16:00");

        startTime.setPromptText("HH:mm");
        endTime.setPromptText("HH:mm");

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10);
        grid.setPadding(new Insets(20));
        grid.addRow(0, new Label("Site: *"), siteBox);
        grid.addRow(1, new Label("Date: *"), datePicker);
        grid.addRow(2, new Label("Start time: *"), startTime);
        grid.addRow(3, new Label("End time: *"), endTime);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(btn -> {
            if (btn == saveBtn) {
                if (siteBox.getValue() == null || datePicker.getValue() == null) return null;
                try {
                    LocalDate date = datePicker.getValue();
                    String[] sp = startTime.getText().split(":");
                    String[] ep = endTime.getText().split(":");
                    LocalDateTime start = date.atTime(Integer.parseInt(sp[0]), Integer.parseInt(sp[1]));
                    LocalDateTime end   = date.atTime(Integer.parseInt(ep[0]), Integer.parseInt(ep[1]));
                    if (end.isBefore(start) || end.equals(start)) {
                        new Alert(Alert.AlertType.ERROR, "End time must be after start time.", ButtonType.OK).showAndWait();
                        return null;
                    }
                    return new Shift("SH" + System.currentTimeMillis(), siteBox.getValue(),
                            start, end, siteBox.getValue().getRequiredSkills());
                } catch (Exception e) {
                    new Alert(Alert.AlertType.ERROR, "Invalid time format. Use HH:mm", ButtonType.OK).showAndWait();
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(shift -> {
            try {
                shiftRepo.saveShift(shift);
                setStatus("✅ Shift created at " + shift.getSite().getName(), false);
                refresh();
            } catch (Exception e) {
                setStatus("❌ Error creating shift: " + e.getMessage(), true);
            }
        });
    }

    @FXML
    private void deleteShift() {
        Shift selected = shiftsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            new Alert(Alert.AlertType.WARNING, "Please select a shift to delete.", ButtonType.OK).showAndWait();
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Shift");
        confirm.setHeaderText("Delete shift at " + (selected.getSite() != null ? selected.getSite().getName() : "?") + "?");
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                try {
                    shiftRepo.deleteShift(selected.getId());
                    setStatus("✅ Shift deleted", false);
                    refresh();
                } catch (Exception e) {
                    setStatus("❌ Error deleting shift: " + e.getMessage(), true);
                }
            }
        });
    }

    private void setStatus(String msg, boolean error) {
        if (statusLabel != null) {
            statusLabel.setText(msg);
            statusLabel.setTextFill(error ? Color.RED : Color.GREEN);
        }
        System.out.println(msg);
    }
}
