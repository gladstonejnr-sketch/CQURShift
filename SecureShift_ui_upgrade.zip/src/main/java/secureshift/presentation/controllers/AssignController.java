package secureshift.presentation.controllers;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import secureshift.data.GuardRepositoryJDBC;
import secureshift.data.ShiftRepositoryJDBC;
import secureshift.domain.Guard;
import secureshift.domain.Shift;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class AssignController {

    @FXML private ComboBox<Shift> shiftBox;
    @FXML private ComboBox<Guard> guardBox;
    @FXML private Label shiftInfoLabel;
    @FXML private Label guardInfoLabel;
    @FXML private Label statusLabel;
    @FXML private Button assignBtn;
    @FXML private Button unassignBtn;

    private final ShiftRepositoryJDBC shiftRepo = new ShiftRepositoryJDBC();
    private final GuardRepositoryJDBC guardRepo = new GuardRepositoryJDBC();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");

    @FXML
    public void initialize() {
        // Shift display
        shiftBox.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Shift s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || s == null) { setText(""); return; }
                String site = s.getSite() != null ? s.getSite().getName() : "?";
                String time = s.getStartTime() != null ? s.getStartTime().format(FMT) : "?";
                setText(site + " — " + time);
            }
        });
        shiftBox.setButtonCell(new ListCell<>() {
            @Override protected void updateItem(Shift s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || s == null) { setText("Select a shift..."); return; }
                String site = s.getSite() != null ? s.getSite().getName() : "?";
                String time = s.getStartTime() != null ? s.getStartTime().format(FMT) : "?";
                setText(site + " — " + time);
            }
        });

        // Guard display
        guardBox.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Guard g, boolean empty) {
                super.updateItem(g, empty);
                if (empty || g == null) { setText(""); return; }
                setText(g.getName() + (g.isAvailable() ? " ✅" : " ❌"));
            }
        });
        guardBox.setButtonCell(new ListCell<>() {
            @Override protected void updateItem(Guard g, boolean empty) {
                super.updateItem(g, empty);
                if (empty || g == null) { setText("Select a guard..."); return; }
                setText(g.getName() + (g.isAvailable() ? " ✅" : " ❌"));
            }
        });

        // Update info labels on selection
        shiftBox.setOnAction(e -> updateShiftInfo());
        guardBox.setOnAction(e -> updateGuardInfo());

        loadData();
    }

    private void loadData() {
        try {
            List<Shift> allShifts = shiftRepo.loadAllShifts();
            List<Guard> allGuards = guardRepo.loadAllGuards();
            shiftBox.setItems(FXCollections.observableArrayList(allShifts));
            guardBox.setItems(FXCollections.observableArrayList(allGuards));
            setStatus("✅ Loaded " + allShifts.size() + " shifts, " + allGuards.size() + " guards", false);
        } catch (Exception e) {
            setStatus("❌ Error loading data: " + e.getMessage(), true);
        }
    }

    @FXML
    public void refresh() {
        shiftBox.getSelectionModel().clearSelection();
        guardBox.getSelectionModel().clearSelection();
        if (shiftInfoLabel != null) shiftInfoLabel.setText("");
        if (guardInfoLabel != null) guardInfoLabel.setText("");
        loadData();
    }

    private void updateShiftInfo() {
        Shift s = shiftBox.getValue();
        if (shiftInfoLabel == null || s == null) return;
        String guard = s.getAssignedGuard() != null ? "Assigned to: " + s.getAssignedGuard().getName() : "Unassigned";
        String duration = String.format("%.1f hrs", s.getDurationHours());
        shiftInfoLabel.setText(duration + " • " + guard);
    }

    private void updateGuardInfo() {
        Guard g = guardBox.getValue();
        if (guardInfoLabel == null || g == null) return;
        String skills = g.getSkills() != null && !g.getSkills().isEmpty()
                ? "Skills: " + String.join(", ", g.getSkills()) : "No skills listed";
        String avail = g.isAvailable() ? "✅ Available" : "❌ Unavailable";
        guardInfoLabel.setText(avail + " • " + skills);
    }

    @FXML
    private void assign() {
        Shift shift = shiftBox.getValue();
        Guard guard = guardBox.getValue();

        if (shift == null || guard == null) {
            setStatus("⚠️ Please select both a shift and a guard.", true);
            return;
        }
        if (!guard.isAvailable()) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Guard Unavailable");
            alert.setHeaderText(guard.getName() + " is currently marked as unavailable.");
            alert.setContentText("Assign anyway?");
            if (alert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;
        }

        shift.assignGuard(guard);
        try {
            shiftRepo.updateAssignment(shift);
            setStatus("✅ " + guard.getName() + " assigned to shift at " +
                    (shift.getSite() != null ? shift.getSite().getName() : "?"), false);
            refresh();
        } catch (Exception e) {
            setStatus("❌ Error assigning guard: " + e.getMessage(), true);
        }
    }

    @FXML
    private void unassign() {
        Shift shift = shiftBox.getValue();
        if (shift == null) {
            setStatus("⚠️ Please select a shift to unassign.", true);
            return;
        }
        if (shift.getAssignedGuard() == null) {
            setStatus("⚠️ This shift has no guard assigned.", true);
            return;
        }
        String name = shift.getAssignedGuard().getName();
        shift.setGuard(null);
        try {
            shiftRepo.updateAssignment(shift);
            setStatus("✅ Guard unassigned from shift (" + name + " removed)", false);
            refresh();
        } catch (Exception e) {
            setStatus("❌ Error unassigning: " + e.getMessage(), true);
        }
    }

    private void setStatus(String msg, boolean error) {
        if (statusLabel != null) {
            statusLabel.setText(msg);
            statusLabel.setTextFill(error ? Color.RED : Color.GREEN);
        }
        System.out.println(msg);
    }
}
